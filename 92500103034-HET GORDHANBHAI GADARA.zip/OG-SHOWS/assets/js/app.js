const $=(s,r=document)=>r.querySelector(s);
function toast(m){let t=$('#toast');if(!t){t=document.createElement('div');t.id='toast';document.body.append(t)}const e=document.createElement('div');e.className='toast';e.textContent=m;t.append(e);setTimeout(()=>e.remove(),2600)}
function nav(active){
 const L=[['index.html','Home'],['movies.html','Movies'],['series.html','Series'],['originals.html','Originals'],['trending.html','Trending'],['my-list.html','My List']];
 document.body.insertAdjacentHTML('afterbegin',`<nav class="top"><button class="burger" onclick="$('.links').classList.toggle('open')">☰</button><a class="logo" href="index.html">OG<b>SHOWS</b></a>
 <div class="links">${L.map(l=>`<a href="${l[0]}" class="${l[0]===active?'on':''}">${l[1]}${l[1]==='My List'?` <span class="cnt" id="lc">${OG.list().length}</span>`:''}</a>`).join('')}<a href="admin.html">Admin</a></div><div class="sp"></div>
 <form action="search.html"><input name="q" placeholder="Search titles, genres, actors" style="width:210px;padding:7px 10px"></form></nav>`);
 const n=$('nav.top');const f=()=>n.classList.toggle('solid',scrollY>40);f();addEventListener('scroll',f);
 addEventListener('og:update',()=>{const c=$('#lc');if(c)c.textContent=OG.list().length});
}
function card(c){const pr=OG.progress()[c.id];
 return `<div class="card" onclick="cardTap(event,'${c.id}')"><span class="q">${c.quality}</span><img loading="lazy" src="${c.poster}" alt="${c.title}">
 <div class="ov"><b>${c.title}</b><span>${c.year} · ★${c.rating} · ${c.genre} · ${c.duration}</span><p>${c.description}</p>
 <div class="cb"><button onclick="event.stopPropagation();location='player.html?id=${c.id}'">▶ Watch</button><button class="g" onclick="event.stopPropagation();listBtn('${c.id}',this)">${OG.inList(c.id)?'✓ Listed':'+ List'}</button></div></div>
 <div class="t">${c.title}<small>${c.year} · ★${c.rating} · ${c.genre}</small></div>${pr?`<div class="bar"><i style="width:${Math.min(100,pr.t/pr.d*100)}%"></i></div>`:''}</div>`}
function cardTap(e,id){const el=e.currentTarget;if(matchMedia('(hover:none)').matches&&!el.classList.contains('tap')){document.querySelectorAll('.card.tap').forEach(x=>x.classList.remove('tap'));el.classList.add('tap');return}location='details.html?id='+id}
function listBtn(id,b){const on=OG.toggleList(id);if(b)b.textContent=on?'✓ Listed':'+ List';toast(on?'Added to My List':'Removed from My List')}
function row(title,items){if(!items.length)return'';return `<section class="row"><h2>${title}</h2><div class="rw"><button class="arr l" onclick="scrollRow(this,-1)">‹</button><div class="sc">${items.map(card).join('')}</div><button class="arr r" onclick="scrollRow(this,1)">›</button></div></section>`}
function scrollRow(b,d){const s=b.parentElement.querySelector('.sc');s.scrollBy({left:d*s.clientWidth*.8})}
const HEAD='<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="css/main.css">';

addEventListener('error',e=>{const i=e.target;if(i&&i.tagName==='IMG'&&!i.dataset.f){i.dataset.f=1;i.src=OG.art(i.alt||'OG SHOWS','',400,600)}},true);
