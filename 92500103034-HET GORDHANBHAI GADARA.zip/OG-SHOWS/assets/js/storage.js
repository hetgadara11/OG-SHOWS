// Shared data layer: client + admin read/write the same localStorage keys.
const OG={
 get(k,d){try{const v=localStorage.getItem('og_'+k);return v?JSON.parse(v):d}catch(e){return d}},
 set(k,v){localStorage.setItem('og_'+k,JSON.stringify(v));window.dispatchEvent(new CustomEvent('og:update',{detail:k}))},
 content(){return this.get('content',[])},
 pub(){return this.content().filter(c=>c.published)},
 find(id){return this.content().find(c=>c.id===id)},
 list(){return this.get('list',[])},
 inList(id){return this.list().includes(id)},
 toggleList(id){let l=this.list();l=l.includes(id)?l.filter(x=>x!==id):[...l,id];this.set('list',l);return l.includes(id)},
 progress(){return this.get('progress',{})},
 saveProgress(id,t,d,ep){const p=this.progress();p[id]={t,d,ep,ts:Date.now()};this.set('progress',p)},
 removeProgress(id){const p=this.progress();delete p[id];this.set('progress',p)}
};
OG.art=function(t,g,w,h){t=String(t||'OG SHOWS');let x=0;for(const ch of (g||t))x=(x*31+ch.charCodeAt(0))%360;
 const esc=z=>z.replace(/&/g,'&amp;').replace(/</g,'&lt;'),ws=t.split(' '),ln=[];let cur='';
 ws.forEach(a=>{if((cur+' '+a).trim().length>(w>h?22:11)&&cur){ln.push(cur);cur=a}else cur=(cur+' '+a).trim()});ln.push(cur);
 const fs=Math.round(w>h?h/7:w/9),y0=h/2-(ln.length-1)*fs*.6;
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><defs><linearGradient id="a" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${x},55%,28%)"/><stop offset="1" stop-color="#08090D"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#a)"/><circle cx="${w*.8}" cy="${h*.2}" r="${h*.3}" fill="hsl(${x},70%,45%)" opacity=".18"/>`+
 `<text x="${w*.06}" y="${h*.1}" font-family="Arial" font-weight="800" font-size="${fs*.5}" fill="#E50914" letter-spacing="2">OG SHOWS</text>`+
 ln.map((l,i)=>`<text x="${w/2}" y="${y0+i*fs*1.2}" text-anchor="middle" font-family="Arial" font-weight="700" font-size="${fs}" fill="#fff">${esc(l)}</text>`).join('')+`</svg>`;
 return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)};
(function seed(){
 if(localStorage.getItem('og_content'))return;
 const V=['BigBuckBunny','ElephantsDream','ForBiggerBlazes','Sintel','TearsOfSteel','ForBiggerEscapes'];
 const cast=['Aarav Kapoor','Mia Sterling','Daniel Cho','Priya Nair','Liam Hart'];
 const S=[['Midnight Protocol','m','Action',2025,8.4,'English',1,1,1],['Neon Requiem','s','Sci-Fi',2026,8.8,'English',1,1,1],['The Last Monsoon','m','Drama',2024,8.1,'Hindi',0,1,0],
 ['Crimson Harbor','s','Crime',2025,8.6,'English',1,0,0],['Echoes of Kutch','m','Adventure',2025,7.9,'Hindi',0,0,0],['Hollow Manor','m','Horror',2024,7.4,'English',0,1,0],
 ['Paper Hearts','m','Romance',2023,7.6,'English',0,0,0],['Laugh Track','s','Comedy',2025,7.8,'Hindi',0,0,0],['Dragon Tide','s','Fantasy',2026,8.5,'English',1,1,0],
 ['Shadow Ledger','m','Thriller',2024,8.0,'English',0,0,0],['Orbit Nine','m','Sci-Fi',2026,8.2,'English',1,1,0],['Dust & Gold','m','Action',2022,7.7,'Hindi',0,0,0],
 ['Velvet Alibi','s','Thriller',2025,8.3,'English',1,0,0],['Cloud Nine Cafe','m','Comedy',2023,7.3,'English',0,0,0],['The Cartographer','m','Adventure',2024,8.0,'English',0,0,0],
 ['Saffron Nights','s','Romance',2025,8.0,'Hindi',1,0,0],['Gridlock','m','Crime',2023,7.5,'English',0,0,0],['Ember Court','s','Fantasy',2024,8.1,'English',0,1,0],
 ['Static','m','Horror',2025,7.2,'English',0,0,0],['Rogue Meridian','m','Action',2026,8.0,'English',1,1,0]];
 const c=S.map((s,i)=>{const id='t'+(i+1),sd=id+s[0].replace(/\W/g,'');
  const o={id,title:s[0],type:s[1]==='m'?'movie':'series',genre:s[2],year:s[3],rating:s[4],language:s[5],duration:s[1]==='m'?(95+i*3)+' min':'3 seasons',
  description:`A gripping ${s[2].toLowerCase()} story from OG SHOWS that follows an unlikely crew as everything they trust begins to unravel.`,
  poster:OG.art(s[0],s[2],400,600),backdrop:OG.art(s[0],s[2],1280,720),video:`https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/${V[i%6]}.mp4`,
  cast:cast.slice(i%3,i%3+3),director:'Rhea Malhotra',quality:i%3?'HD':'4K',featured:!!s[6],trending:!!s[7],original:!!s[8],published:true,added:Date.now()-i*864e5};
  if(o.type==='series')o.episodes=[1,2,3].flatMap(se=>[1,2,3,4].map(e=>({id:`${id}s${se}e${e}`,season:se,ep:e,title:`Episode ${e}: ${['Pilot','Fault Lines','The Offer','Reckoning'][e-1]}`,duration:'42 min',description:'The stakes rise as new secrets surface.',thumb:OG.art(s[0]+' S'+se+'E'+e,s[2],480,270),video:V[(i+e)%6]?`https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/${V[(i+e)%6]}.mp4`:o.video})));
  return o});
 localStorage.setItem('og_content',JSON.stringify(c));
})();

// Migrate older saved data that still points at remote placeholder images
(function(){try{const c=JSON.parse(localStorage.getItem('og_content')||'[]');let ch=false;
 const bad=u=>!u||/picsum\.photos/.test(u);
 c.forEach(o=>{if(bad(o.poster)){o.poster=OG.art(o.title,o.genre,400,600);ch=true}if(bad(o.backdrop)){o.backdrop=OG.art(o.title,o.genre,1280,720);ch=true}
  (o.episodes||[]).forEach(e=>{if(bad(e.thumb)){e.thumb=OG.art(o.title+' S'+e.season+'E'+e.ep,o.genre,480,270);ch=true}})});
 if(ch)localStorage.setItem('og_content',JSON.stringify(c))}catch(e){}})();
